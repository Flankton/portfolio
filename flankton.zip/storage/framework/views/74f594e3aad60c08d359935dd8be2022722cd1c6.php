teste
<?php /**PATH C:\Users\PMSC\Documents\William\projetos\portifólio\flankton\resources\views/mail/email.blade.php ENDPATH**/ ?>