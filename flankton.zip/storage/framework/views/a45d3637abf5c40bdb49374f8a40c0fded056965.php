<?php echo e($slot); ?>

<?php /**PATH C:\Users\PMSC\Documents\William\projetos\portifólio\flankton\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>