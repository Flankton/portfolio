<?php $__env->startComponent('mail::message'); ?>
# Introduction

The body of your message.

<?php $__env->startComponent('mail::button', ['url' => 'google.com']); ?>
EMAIL
<?php echo $__env->renderComponent(); ?>
<?php echo e($dados->name); ?> <br>
<?php echo e($dados->email); ?> <br>
<?php echo e($dados->subject); ?> <br>
<?php echo e($dados->message); ?> <br>

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\Users\PMSC\Documents\William\projetos\portifólio\flankton\resources\views/emails/welcome.blade.php ENDPATH**/ ?>